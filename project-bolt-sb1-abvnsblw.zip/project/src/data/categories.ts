export const categories = [
  {
    id: 1,
    name: "Face",
    description: "Foundations, concealers, powders, and primers",
    slug: "face"
  },
  {
    id: 2,
    name: "Eyes",
    description: "Eyeshadows, liners, mascaras, and brow products",
    slug: "eyes"
  },
  {
    id: 3,
    name: "Lips",
    description: "Lipsticks, glosses, liners, and balms",
    slug: "lips"
  },
  {
    id: 4,
    name: "Cheeks",
    description: "Blushes, bronzers, contour, and highlighters",
    slug: "cheeks"
  },
  {
    id: 5,
    name: "Skincare",
    description: "Cleansers, moisturizers, serums, and masks",
    slug: "skincare"
  },
  {
    id: 6,
    name: "Tools",
    description: "Brushes, sponges, and application tools",
    slug: "tools"
  }
];
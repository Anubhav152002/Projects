import { Product } from '../types/product';

// Sample products data
export const allProducts: Product[] = [
  {
    id: 1,
    name: "Luminous Silk Foundation",
    price: 52.00,
    originalPrice: null,
    shortDescription: "Lightweight, buildable coverage with a radiant finish",
    longDescription: "Our award-winning Luminous Silk Foundation delivers medium, buildable coverage with a radiant finish. This lightweight, silky formula enhances your natural complexion without masking it, creating a flawless airbrushed effect that lasts all day.",
    images: [
      "https://images.pexels.com/photos/2113855/pexels-photo-2113855.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/4465124/pexels-photo-4465124.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 1,
    isNew: false,
    discount: 0,
    rating: 4.8,
    reviewCount: 245,
    benefits: [
      "Lightweight, breathable formula",
      "Buildable coverage from sheer to medium",
      "Oil-free and non-comedogenic",
      "Suits all skin types"
    ],
    ingredients: "Aqua/Water, Cyclopentasiloxane, Glycerin, Isododecane, Alcohol Denat, PEG-10 Dimethicone, Talc, Phenyl Trimethicone, Polymethylsilsesquioxane, Nylon-12, Disteardimonium Hectorite.",
    howToUse: [
      "Apply to clean, moisturized skin",
      "Dispense 1-2 pumps onto the back of your hand",
      "Using fingers, brush, or sponge, blend from the center of the face outward",
      "Build up layers as needed for desired coverage"
    ]
  },
  {
    id: 2,
    name: "Radiant Concealer",
    price: 28.00,
    originalPrice: 35.00,
    shortDescription: "Creamy concealer that brightens and covers imperfections",
    longDescription: "Our Radiant Concealer is your secret weapon against dark circles, blemishes, and imperfections. The creamy formula blends seamlessly into skin while providing long-lasting, crease-resistant coverage. Infused with light-reflecting particles to brighten the under-eye area.",
    images: [
      "https://images.pexels.com/photos/2533266/pexels-photo-2533266.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/2537930/pexels-photo-2537930.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 1,
    isNew: false,
    discount: 20,
    rating: 4.7,
    reviewCount: 189,
    benefits: [
      "Brightens dark circles",
      "Covers imperfections and blemishes",
      "Crease-resistant formula",
      "Hydrating and long-lasting"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 3,
    name: "Velvet Matte Lipstick",
    price: 24.00,
    originalPrice: null,
    shortDescription: "Rich, highly pigmented color with a comfortable matte finish",
    longDescription: "Our Velvet Matte Lipstick delivers intense color in one swipe with a soft, comfortable matte finish. The lightweight formula is enriched with moisturizing ingredients to prevent drying, while offering long-lasting, transfer-resistant wear.",
    images: [
      "https://images.pexels.com/photos/2558247/pexels-photo-2558247.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/2697786/pexels-photo-2697786.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 3,
    isNew: true,
    discount: 0,
    rating: 4.9,
    reviewCount: 312,
    benefits: [
      "Highly pigmented, one-swipe color",
      "Comfortable matte finish",
      "Long-lasting, transfer-resistant formula",
      "Infused with moisturizing ingredients"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 4,
    name: "Precision Brow Pencil",
    price: 22.00,
    originalPrice: null,
    shortDescription: "Define and fill brows with natural-looking precision",
    longDescription: "Our Precision Brow Pencil features an ultra-fine tip that mimics natural hair, allowing you to create detailed, hair-like strokes. The waterproof formula ensures your brows stay perfectly defined all day, while the spoolie brush helps blend for a natural finish.",
    images: [
      "https://images.pexels.com/photos/2534561/pexels-photo-2534561.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/7230250/pexels-photo-7230250.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 2,
    isNew: false,
    discount: 0,
    rating: 4.6,
    reviewCount: 178,
    benefits: [
      "Ultra-fine tip for precise application",
      "Waterproof, smudge-proof formula",
      "Built-in spoolie brush for blending",
      "Long-lasting wear"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 5,
    name: "Glow Liquid Highlighter",
    price: 34.00,
    originalPrice: 42.00,
    shortDescription: "Pearlescent liquid highlighter for a luminous glow",
    longDescription: "Our Glow Liquid Highlighter imparts a subtle, dewy radiance to the skin. The lightweight, buildable formula can be worn alone, mixed with foundation, or applied as a targeted highlight. Pearl pigments reflect light for a natural-looking luminosity.",
    images: [
      "https://images.pexels.com/photos/2535913/pexels-photo-2535913.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/3786795/pexels-photo-3786795.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 4,
    isNew: true,
    discount: 15,
    rating: 4.9,
    reviewCount: 201,
    benefits: [
      "Pearlescent finish for subtle radiance",
      "Buildable formula for customizable glow",
      "Versatile - wear alone or mix with foundation",
      "Lightweight, non-greasy texture"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 6,
    name: "Volumizing Mascara",
    price: 26.00,
    originalPrice: null,
    shortDescription: "Dramatic volume and length without clumping",
    longDescription: "Our Volumizing Mascara creates incredible volume, length, and definition without clumping or smudging. The innovative brush design separates and coats each lash from root to tip, while the buildable formula allows you to customize your look from natural to dramatic.",
    images: [
      "https://images.pexels.com/photos/4620843/pexels-photo-4620843.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/1377034/pexels-photo-1377034.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 2,
    isNew: false,
    discount: 0,
    rating: 4.7,
    reviewCount: 230,
    benefits: [
      "Volumizes, lengthens, and defines lashes",
      "No clumping, flaking, or smudging",
      "Buildable formula for natural to dramatic looks",
      "Long-wearing, all-day formula"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 7,
    name: "Hydrating Lip Gloss",
    price: 20.00,
    originalPrice: null,
    shortDescription: "Sheer, hydrating gloss with a non-sticky finish",
    longDescription: "Our Hydrating Lip Gloss delivers a perfect combination of color and shine without stickiness. Infused with nourishing oils and vitamin E, this formula keeps lips soft and moisturized while imparting a lustrous, plumping effect.",
    images: [
      "https://images.pexels.com/photos/4620838/pexels-photo-4620838.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/2253834/pexels-photo-2253834.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 3,
    isNew: false,
    discount: 0,
    rating: 4.5,
    reviewCount: 165,
    benefits: [
      "Lustrous shine without stickiness",
      "Hydrating formula with nourishing oils",
      "Subtle plumping effect",
      "Comfortable, long-wearing formula"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 8,
    name: "Silk Setting Powder",
    price: 38.00,
    originalPrice: null,
    shortDescription: "Silky-smooth powder that sets makeup without looking cakey",
    longDescription: "Our Silk Setting Powder is a finely-milled, lightweight powder that sets makeup for all-day wear without looking dry or cakey. The translucent formula works on all skin tones, minimizes the appearance of pores, and controls shine while maintaining a natural finish.",
    images: [
      "https://images.pexels.com/photos/2535906/pexels-photo-2535906.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/2113855/pexels-photo-2113855.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 1,
    isNew: false,
    discount: 0,
    rating: 4.8,
    reviewCount: 198,
    benefits: [
      "Silky-smooth, lightweight texture",
      "Sets makeup without looking dry or cakey",
      "Minimizes pores and controls shine",
      "Works on all skin tones"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 9,
    name: "Rose Quartz Facial Roller",
    price: 28.00,
    originalPrice: 35.00,
    shortDescription: "Cool rose quartz roller to reduce puffiness and enhance glow",
    longDescription: "Our Rose Quartz Facial Roller helps to reduce puffiness, promote circulation, and enhance skin's natural glow. The larger end is designed for cheeks, forehead, and jawline, while the smaller end targets the under-eye area and around the nose. Use with your favorite serums for enhanced absorption.",
    images: [
      "https://images.pexels.com/photos/3997383/pexels-photo-3997383.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/4202326/pexels-photo-4202326.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 6,
    isNew: false,
    discount: 20,
    rating: 4.6,
    reviewCount: 152,
    benefits: [
      "Reduces puffiness and promotes circulation",
      "Enhances product absorption",
      "Provides cooling, soothing relief",
      "Improves skin's natural glow"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 10,
    name: "Vitamin C Brightening Serum",
    price: 48.00,
    originalPrice: null,
    shortDescription: "Potent vitamin C serum that brightens and evens skin tone",
    longDescription: "Our Vitamin C Brightening Serum features a stabilized 15% vitamin C formula that visibly brightens skin, evens tone, and protects against environmental damage. The lightweight texture absorbs quickly, leaving skin radiant and smooth without any sticky residue.",
    images: [
      "https://images.pexels.com/photos/4465124/pexels-photo-4465124.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/5069605/pexels-photo-5069605.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 5,
    isNew: true,
    discount: 0,
    rating: 4.9,
    reviewCount: 267,
    benefits: [
      "Brightens and evens skin tone",
      "Provides antioxidant protection",
      "Reduces the appearance of dark spots",
      "Promotes collagen production"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 11,
    name: "Precision Eyeliner Pen",
    price: 22.00,
    originalPrice: null,
    shortDescription: "Ultra-fine tip liquid liner for precise application",
    longDescription: "Our Precision Eyeliner Pen features an ultra-fine felt tip that allows for precise application, from the thinnest lines to dramatic wings. The quick-drying, waterproof formula stays put for up to 12 hours without smudging, flaking, or fading.",
    images: [
      "https://images.pexels.com/photos/4620762/pexels-photo-4620762.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/3785649/pexels-photo-3785649.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 2,
    isNew: false,
    discount: 0,
    rating: 4.7,
    reviewCount: 183,
    benefits: [
      "Ultra-fine tip for precise application",
      "Waterproof, smudge-proof formula",
      "Quick-drying, long-lasting wear",
      "Intense black pigment"
    ],
    ingredients: null,
    howToUse: null
  },
  {
    id: 12,
    name: "Hydrating Face Mist",
    price: 26.00,
    originalPrice: null,
    shortDescription: "Refreshing face mist that hydrates and revitalizes skin",
    longDescription: "Our Hydrating Face Mist instantly refreshes and hydrates skin with a blend of rose water, hyaluronic acid, and antioxidants. Perfect for use throughout the day to revitalize makeup, set your look, or provide a boost of moisture whenever skin needs it.",
    images: [
      "https://images.pexels.com/photos/4465809/pexels-photo-4465809.jpeg?auto=compress&cs=tinysrgb&w=500",
      "https://images.pexels.com/photos/4389870/pexels-photo-4389870.jpeg?auto=compress&cs=tinysrgb&w=500"
    ],
    categoryId: 5,
    isNew: false,
    discount: 0,
    rating: 4.5,
    reviewCount: 142,
    benefits: [
      "Instantly hydrates and refreshes skin",
      "Sets makeup and extends wear",
      "Can be used throughout the day",
      "Infused with antioxidants and botanicals"
    ],
    ingredients: null,
    howToUse: null
  }
];

// Featured products - a subset of all products
export const featuredProducts = [
  allProducts[0], // Luminous Silk Foundation
  allProducts[2], // Velvet Matte Lipstick
  allProducts[4], // Glow Liquid Highlighter
  allProducts[9]  // Vitamin C Brightening Serum
];

// Best sellers - another subset
export const bestSellerProducts = [
  allProducts[2], // Velvet Matte Lipstick
  allProducts[5], // Volumizing Mascara
  allProducts[0], // Luminous Silk Foundation
  allProducts[7]  // Silk Setting Powder
];
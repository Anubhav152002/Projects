export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice: number | null;
  shortDescription: string;
  longDescription: string | null;
  images: string[];
  categoryId: number;
  isNew: boolean;
  discount: number;
  rating: number;
  reviewCount: number;
  benefits: string[];
  ingredients: string | null;
  howToUse: string[] | null;
}
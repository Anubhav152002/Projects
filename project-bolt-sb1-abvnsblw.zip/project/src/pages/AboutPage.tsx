import React, { useEffect } from 'react';

const AboutPage: React.FC = () => {
  useEffect(() => {
    document.title = 'About Us | Lumière';
  }, []);

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-serif font-bold text-plum mb-8 text-center">About Lumière</h1>
          
          <div className="prose prose-lg max-w-none text-gray-600">
            <p className="lead text-xl">
              Lumière is a luxury beauty brand founded on the belief that makeup should not only enhance your natural beauty but also be good for your skin.
            </p>

            <div className="my-12 relative rounded-lg overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/2983464/pexels-photo-2983464.jpeg?auto=compress&cs=tinysrgb&w=1600" 
                alt="Lumière beauty products" 
                className="w-full h-auto object-cover rounded-lg"
              />
            </div>

            <h2 className="text-2xl font-serif font-bold text-plum mt-8 mb-4">Our Story</h2>
            <p>
              Founded in 2018 by makeup artist Claire Laurent, Lumière began as a small collection of essential products designed to create a flawless, natural look. Claire's vision was simple: create makeup that performs beautifully while using clean, skin-nourishing ingredients.
            </p>
            <p>
              After years of working with clients who struggled to find products that wouldn't irritate their skin or cause breakouts, Claire set out to develop her own line. Working with top cosmetic chemists and dermatologists, she spent two years perfecting formulations that deliver professional results without compromising on ingredient quality.
            </p>

            <h2 className="text-2xl font-serif font-bold text-plum mt-8 mb-4">Our Philosophy</h2>
            <p>
              At Lumière, we believe that beauty products should be:
            </p>
            <ul>
              <li><strong>Effective</strong> - Our products deliver professional results that last</li>
              <li><strong>Inclusive</strong> - We create products for all skin tones and types</li>
              <li><strong>Clean</strong> - We use high-quality ingredients that benefit your skin</li>
              <li><strong>Ethical</strong> - We never test on animals and prioritize sustainable practices</li>
            </ul>

            <div className="my-12 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="rounded-lg overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/2533266/pexels-photo-2533266.jpeg?auto=compress&cs=tinysrgb&w=1600" 
                  alt="Product development" 
                  className="w-full h-full object-cover aspect-square"
                />
              </div>
              <div className="rounded-lg overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/3373739/pexels-photo-3373739.jpeg?auto=compress&cs=tinysrgb&w=1600" 
                  alt="Makeup application" 
                  className="w-full h-full object-cover aspect-square"
                />
              </div>
              <div className="rounded-lg overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=1600" 
                  alt="Product display" 
                  className="w-full h-full object-cover aspect-square"
                />
              </div>
            </div>

            <h2 className="text-2xl font-serif font-bold text-plum mt-8 mb-4">Our Commitment to Sustainability</h2>
            <p>
              We're committed to reducing our environmental impact through:
            </p>
            <ul>
              <li>Recyclable and biodegradable packaging whenever possible</li>
              <li>Reducing plastic use throughout our supply chain</li>
              <li>Carbon-neutral shipping</li>
              <li>Partnerships with environmental organizations</li>
            </ul>
            <p>
              By 2025, we aim to have 100% of our packaging be either recyclable, refillable, or compostable.
            </p>

            <h2 className="text-2xl font-serif font-bold text-plum mt-8 mb-4">Join Our Community</h2>
            <p>
              Lumière is more than just a beauty brand—it's a community of beauty enthusiasts who believe in the power of self-expression through makeup. We invite you to join us on this journey to redefine beauty standards and promote self-confidence.
            </p>
            <p>
              Follow us on social media for makeup tutorials, product launches, and to connect with other Lumière lovers.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
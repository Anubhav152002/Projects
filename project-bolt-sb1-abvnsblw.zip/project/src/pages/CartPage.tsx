import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Trash2, ShoppingBag, ChevronLeft, Minus, Plus, AlertCircle } from 'lucide-react';
import { useCart } from '../context/CartContext';

const CartPage: React.FC = () => {
  const { cartItems, removeFromCart, updateQuantity, totalItems, totalPrice } = useCart();

  useEffect(() => {
    document.title = 'Shopping Cart | Lumière';
  }, []);

  // Calculate shipping cost based on total price
  const shippingCost = totalPrice > 50 ? 0 : 5.99;
  const taxRate = 0.07; // 7% tax rate
  const taxAmount = totalPrice * taxRate;
  const orderTotal = totalPrice + shippingCost + taxAmount;

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl font-serif font-bold text-plum mb-8">Your Shopping Cart</h1>

        {cartItems.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <ShoppingBag size={64} className="mx-auto text-gray-300 mb-4" />
            <h2 className="text-2xl font-medium text-plum mb-2">Your cart is empty</h2>
            <p className="text-gray-500 mb-8">
              Looks like you haven't added any products to your cart yet.
            </p>
            <Link
              to="/products"
              className="inline-flex items-center px-6 py-3 bg-plum text-white font-medium rounded-md hover:bg-plum/90 transition-colors"
            >
              <ChevronLeft size={18} className="mr-2" />
              Continue Shopping
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="p-6">
                  <h2 className="text-xl font-medium text-plum mb-4">Cart Items ({totalItems})</h2>
                  
                  <div className="divide-y divide-gray-100">
                    {cartItems.map((item) => (
                      <div key={item.product.id} className="py-6 flex flex-col sm:flex-row">
                        <div className="flex-shrink-0 w-full sm:w-24 h-24 bg-gray-50 rounded-md overflow-hidden mb-4 sm:mb-0">
                          <Link to={`/products/${item.product.id}`}>
                            <img
                              src={item.product.images[0]}
                              alt={item.product.name}
                              className="w-full h-full object-cover"
                            />
                          </Link>
                        </div>
                        
                        <div className="flex-grow sm:ml-6 flex flex-col">
                          <div className="flex justify-between mb-2">
                            <Link 
                              to={`/products/${item.product.id}`}
                              className="text-plum font-medium hover:text-rose-gold"
                            >
                              {item.product.name}
                            </Link>
                            <span className="font-medium text-plum">
                              ${(item.product.price * item.quantity).toFixed(2)}
                            </span>
                          </div>
                          
                          {item.product.shortDescription && (
                            <p className="text-gray-500 text-sm mb-2 line-clamp-1">
                              {item.product.shortDescription}
                            </p>
                          )}
                          
                          <div className="mt-auto flex flex-wrap justify-between items-center gap-4">
                            <div className="flex items-center border border-gray-200 rounded-md">
                              <button
                                onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                                className="px-2 py-1 text-gray-500 hover:text-plum"
                                disabled={item.quantity <= 1}
                              >
                                <Minus size={14} />
                              </button>
                              <span className="px-3 py-1 border-x border-gray-200 min-w-[40px] text-center text-sm">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                                className="px-2 py-1 text-gray-500 hover:text-plum"
                              >
                                <Plus size={14} />
                              </button>
                            </div>
                            
                            <div className="flex items-center">
                              <span className="text-sm text-gray-500 mr-4">
                                ${item.product.price.toFixed(2)} each
                              </span>
                              <button
                                onClick={() => removeFromCart(item.product.id)}
                                className="text-gray-400 hover:text-red-500"
                                aria-label="Remove item"
                              >
                                <Trash2 size={18} />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="bg-gray-50 px-6 py-4">
                  <Link
                    to="/products"
                    className="inline-flex items-center text-plum hover:text-rose-gold"
                  >
                    <ChevronLeft size={16} className="mr-1" />
                    Continue Shopping
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Order Summary */}
            <div>
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <div className="p-6">
                  <h2 className="text-xl font-medium text-plum mb-4">Order Summary</h2>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Subtotal</span>
                      <span className="text-plum">${totalPrice.toFixed(2)}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600">Shipping</span>
                      {shippingCost === 0 ? (
                        <span className="text-green-600">Free</span>
                      ) : (
                        <span className="text-plum">${shippingCost.toFixed(2)}</span>
                      )}
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tax (7%)</span>
                      <span className="text-plum">${taxAmount.toFixed(2)}</span>
                    </div>
                    
                    <div className="h-px bg-gray-200 my-4"></div>
                    
                    <div className="flex justify-between font-medium">
                      <span className="text-gray-900">Order Total</span>
                      <span className="text-plum text-lg">${orderTotal.toFixed(2)}</span>
                    </div>
                  </div>
                  
                  {shippingCost > 0 && (
                    <div className="mt-4 flex items-start bg-blue-50 text-blue-700 p-3 rounded-md text-sm">
                      <AlertCircle size={16} className="mr-2 flex-shrink-0 mt-0.5" />
                      <p>
                        Add <span className="font-medium">${(50 - totalPrice).toFixed(2)}</span> more to qualify for free shipping!
                      </p>
                    </div>
                  )}
                  
                  <button
                    className="w-full mt-6 py-3 bg-rose-gold text-white font-medium rounded-md hover:bg-rose-gold/90 transition-colors"
                  >
                    Proceed to Checkout
                  </button>
                  
                  <div className="mt-6">
                    <h3 className="font-medium text-plum mb-2">We Accept</h3>
                    <div className="flex space-x-2">
                      <div className="w-10 h-6 bg-gray-100 rounded"></div>
                      <div className="w-10 h-6 bg-gray-100 rounded"></div>
                      <div className="w-10 h-6 bg-gray-100 rounded"></div>
                      <div className="w-10 h-6 bg-gray-100 rounded"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CartPage;
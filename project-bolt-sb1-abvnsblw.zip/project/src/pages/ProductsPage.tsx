import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, SlidersHorizontal, ChevronDown, X } from 'lucide-react';
import ProductGrid from '../components/product/ProductGrid';
import { allProducts } from '../data/products';
import { categories } from '../data/categories';

const sortOptions = [
  { value: 'featured', label: 'Featured' },
  { value: 'newest', label: 'Newest' },
  { value: 'price-low', label: 'Price: Low to High' },
  { value: 'price-high', label: 'Price: High to Low' },
  { value: 'popular', label: 'Most Popular' },
  { value: 'rating', label: 'Highest Rated' }
];

const ProductsPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState(allProducts);
  const [activeFilters, setActiveFilters] = useState<Record<string, string[]>>({
    category: [],
    price: [],
    rating: []
  });
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState('featured');

  // Price ranges
  const priceRanges = [
    { id: 'under-25', label: 'Under $25', min: 0, max: 25 },
    { id: '25-50', label: '$25 to $50', min: 25, max: 50 },
    { id: '50-100', label: '$50 to $100', min: 50, max: 100 },
    { id: 'over-100', label: 'Over $100', min: 100, max: Infinity }
  ];

  useEffect(() => {
    document.title = 'Shop All Products | Lumière';
    
    // Handle URL parameters
    const categoryParam = searchParams.get('category');
    const sortParam = searchParams.get('sort');
    const priceParam = searchParams.get('price');
    const ratingParam = searchParams.get('rating');
    
    if (categoryParam) {
      setActiveFilters(prev => ({
        ...prev,
        category: [categoryParam]
      }));
    }
    
    if (sortParam) {
      setSortBy(sortParam);
    }
    
    if (priceParam) {
      setActiveFilters(prev => ({
        ...prev,
        price: [priceParam]
      }));
    }
    
    if (ratingParam) {
      setActiveFilters(prev => ({
        ...prev,
        rating: [ratingParam]
      }));
    }
  }, [searchParams]);

  useEffect(() => {
    // Apply filters and sorting
    let filteredProducts = [...allProducts];
    
    // Apply category filter
    if (activeFilters.category.length > 0) {
      filteredProducts = filteredProducts.filter(product => 
        activeFilters.category.includes(product.categoryId.toString())
      );
    }
    
    // Apply price filter
    if (activeFilters.price.length > 0) {
      filteredProducts = filteredProducts.filter(product => {
        return activeFilters.price.some(priceRangeId => {
          const range = priceRanges.find(r => r.id === priceRangeId);
          if (range) {
            return product.price >= range.min && product.price < range.max;
          }
          return false;
        });
      });
    }
    
    // Apply rating filter
    if (activeFilters.rating.length > 0) {
      const minRating = Math.min(...activeFilters.rating.map(r => parseInt(r)));
      filteredProducts = filteredProducts.filter(product => product.rating >= minRating);
    }
    
    // Apply sorting
    switch(sortBy) {
      case 'newest':
        filteredProducts.sort((a, b) => b.id - a.id);
        break;
      case 'price-low':
        filteredProducts.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filteredProducts.sort((a, b) => b.price - a.price);
        break;
      case 'popular':
        filteredProducts.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      case 'rating':
        filteredProducts.sort((a, b) => b.rating - a.rating);
        break;
      // 'featured' is default order
      default:
        break;
    }
    
    setProducts(filteredProducts);
    
    // Update URL parameters
    const params = new URLSearchParams();
    
    if (activeFilters.category.length > 0) {
      params.set('category', activeFilters.category[0]);
    }
    
    if (sortBy !== 'featured') {
      params.set('sort', sortBy);
    }
    
    if (activeFilters.price.length > 0) {
      params.set('price', activeFilters.price[0]);
    }
    
    if (activeFilters.rating.length > 0) {
      params.set('rating', activeFilters.rating[0]);
    }
    
    setSearchParams(params, { replace: true });
  }, [activeFilters, sortBy, setSearchParams]);

  const toggleFilter = (type: string, value: string) => {
    setActiveFilters(prev => {
      const current = [...(prev[type] || [])];
      
      if (current.includes(value)) {
        return {
          ...prev,
          [type]: current.filter(item => item !== value)
        };
      } else {
        // For category, price, and rating, we want to select only one at a time
        return {
          ...prev,
          [type]: [value]
        };
      }
    });
  };

  const clearFilters = () => {
    setActiveFilters({
      category: [],
      price: [],
      rating: []
    });
    setSortBy('featured');
  };

  const hasActiveFilters = () => {
    return (
      activeFilters.category.length > 0 ||
      activeFilters.price.length > 0 ||
      activeFilters.rating.length > 0 ||
      sortBy !== 'featured'
    );
  };

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-serif font-bold text-plum">All Products</h1>
          <div className="flex gap-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 text-plum md:hidden"
            >
              <Filter size={18} />
              Filters
            </button>
            
            <div className="hidden md:block relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none pl-4 pr-10 py-2 border border-gray-200 rounded-md bg-white text-plum focus:outline-none focus:border-rose-gold"
              >
                {sortOptions.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <ChevronDown 
                size={18} 
                className="absolute top-1/2 right-3 transform -translate-y-1/2 text-gray-400 pointer-events-none" 
              />
            </div>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filter Sidebar */}
          <div 
            className={`w-full md:w-64 flex-shrink-0 ${
              showFilters ? 'block fixed inset-0 z-50 bg-white p-4 overflow-auto' : 'hidden md:block'
            }`}
          >
            <div className="flex justify-between items-center md:hidden mb-4">
              <h2 className="text-xl font-bold text-plum">Filters</h2>
              <button onClick={() => setShowFilters(false)}>
                <X size={24} />
              </button>
            </div>
            
            {hasActiveFilters() && (
              <div className="mb-6 flex justify-between items-center">
                <span className="text-sm text-gray-500">
                  {products.length} products
                </span>
                <button 
                  onClick={clearFilters}
                  className="text-rose-gold text-sm hover:underline"
                >
                  Clear All
                </button>
              </div>
            )}
            
            {/* Categories Filter */}
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-3 text-plum">Categories</h3>
              <div className="space-y-2">
                {categories.map(category => (
                  <div key={category.id} className="flex items-center">
                    <input
                      type="checkbox"
                      id={`category-${category.id}`}
                      checked={activeFilters.category.includes(category.id.toString())}
                      onChange={() => toggleFilter('category', category.id.toString())}
                      className="rounded text-rose-gold focus:ring-rose-gold"
                    />
                    <label htmlFor={`category-${category.id}`} className="ml-2 text-gray-700">
                      {category.name}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Price Filter */}
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-3 text-plum">Price</h3>
              <div className="space-y-2">
                {priceRanges.map(range => (
                  <div key={range.id} className="flex items-center">
                    <input
                      type="checkbox"
                      id={`price-${range.id}`}
                      checked={activeFilters.price.includes(range.id)}
                      onChange={() => toggleFilter('price', range.id)}
                      className="rounded text-rose-gold focus:ring-rose-gold"
                    />
                    <label htmlFor={`price-${range.id}`} className="ml-2 text-gray-700">
                      {range.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Rating Filter */}
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-3 text-plum">Rating</h3>
              <div className="space-y-2">
                {[4, 3, 2, 1].map(rating => (
                  <div key={rating} className="flex items-center">
                    <input
                      type="checkbox"
                      id={`rating-${rating}`}
                      checked={activeFilters.rating.includes(rating.toString())}
                      onChange={() => toggleFilter('rating', rating.toString())}
                      className="rounded text-rose-gold focus:ring-rose-gold"
                    />
                    <label htmlFor={`rating-${rating}`} className="ml-2 flex items-center">
                      <span className="flex">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <svg 
                            key={i} 
                            className={`w-4 h-4 ${i < rating ? 'text-amber-400' : 'text-gray-300'}`} 
                            fill="currentColor" 
                            viewBox="0 0 20 20"
                          >
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                      </span>
                      <span className="ml-1 text-gray-700">& Up</span>
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Mobile Sort */}
            <div className="md:hidden mb-6">
              <h3 className="text-lg font-medium mb-3 text-plum">Sort By</h3>
              <div className="space-y-2">
                {sortOptions.map(option => (
                  <div key={option.value} className="flex items-center">
                    <input
                      type="radio"
                      id={`sort-${option.value}`}
                      name="sort"
                      checked={sortBy === option.value}
                      onChange={() => setSortBy(option.value)}
                      className="text-rose-gold focus:ring-rose-gold"
                    />
                    <label htmlFor={`sort-${option.value}`} className="ml-2 text-gray-700">
                      {option.label}
                    </label>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Apply Filters Button (Mobile) */}
            <div className="md:hidden mt-6">
              <button
                onClick={() => setShowFilters(false)}
                className="w-full py-3 bg-plum text-white font-medium rounded-md"
              >
                Apply Filters
              </button>
            </div>
          </div>
          
          {/* Products Grid */}
          <div className="flex-grow">
            {/* Active Filters */}
            {hasActiveFilters() && (
              <div className="mb-6 flex flex-wrap gap-2">
                {activeFilters.category.map(categoryId => {
                  const category = categories.find(c => c.id.toString() === categoryId);
                  return category ? (
                    <div 
                      key={`filter-category-${categoryId}`}
                      className="flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm"
                    >
                      <span>Category: {category.name}</span>
                      <button 
                        onClick={() => toggleFilter('category', categoryId)}
                        className="ml-2 text-gray-500 hover:text-plum"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ) : null;
                })}
                
                {activeFilters.price.map(priceId => {
                  const price = priceRanges.find(p => p.id === priceId);
                  return price ? (
                    <div 
                      key={`filter-price-${priceId}`}
                      className="flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm"
                    >
                      <span>Price: {price.label}</span>
                      <button 
                        onClick={() => toggleFilter('price', priceId)}
                        className="ml-2 text-gray-500 hover:text-plum"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ) : null;
                })}
                
                {activeFilters.rating.map(ratingValue => (
                  <div 
                    key={`filter-rating-${ratingValue}`}
                    className="flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm"
                  >
                    <span>Rating: {ratingValue}+ Stars</span>
                    <button 
                      onClick={() => toggleFilter('rating', ratingValue)}
                      className="ml-2 text-gray-500 hover:text-plum"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ))}
                
                {sortBy !== 'featured' && (
                  <div 
                    className="flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm"
                  >
                    <span>Sort: {sortOptions.find(o => o.value === sortBy)?.label}</span>
                    <button 
                      onClick={() => setSortBy('featured')}
                      className="ml-2 text-gray-500 hover:text-plum"
                    >
                      <X size={14} />
                    </button>
                  </div>
                )}
              </div>
            )}
            
            {products.length === 0 ? (
              <div className="text-center py-12">
                <SlidersHorizontal size={48} className="mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-medium text-plum mb-2">No products found</h3>
                <p className="text-gray-500">Try adjusting your filters to find what you're looking for.</p>
                <button 
                  onClick={clearFilters}
                  className="mt-4 px-4 py-2 bg-plum text-white rounded-md hover:bg-plum/90 transition-colors"
                >
                  Clear All Filters
                </button>
              </div>
            ) : (
              <>
                <p className="mb-6 text-sm text-gray-500">Showing {products.length} products</p>
                <ProductGrid products={products} />
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;
import React, { useEffect } from 'react';
import Hero from '../components/home/Hero';
import FeaturedProducts from '../components/home/FeaturedProducts';
import Collections from '../components/home/Collections';
import BestSellers from '../components/home/BestSellers';
import Testimonials from '../components/home/Testimonials';
import NewsletterSection from '../components/home/NewsletterSection';

const HomePage: React.FC = () => {
  useEffect(() => {
    // Update page title
    document.title = 'Lumière | Luxury Makeup & Beauty Products';
  }, []);

  return (
    <div>
      <Hero />
      <FeaturedProducts />
      <Collections />
      <BestSellers />
      <Testimonials />
      <NewsletterSection />
    </div>
  );
};

export default HomePage;
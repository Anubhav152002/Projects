import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ChevronRight, Star, Truck, Shield, RotateCcw, Minus, Plus, Heart, ShoppingBag } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { allProducts } from '../data/products';
import { categories } from '../data/categories';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(allProducts[0]);
  const [selectedImage, setSelectedImage] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description');
  const [isFavorite, setIsFavorite] = useState(false);

  useEffect(() => {
    if (id) {
      const foundProduct = allProducts.find(p => p.id === parseInt(id));
      if (foundProduct) {
        setProduct(foundProduct);
        setSelectedImage(foundProduct.images[0]);
        document.title = `${foundProduct.name} | Lumière`;
      }
    }
  }, [id]);

  const category = categories.find(c => c.id === product.categoryId);

  const handleAddToCart = () => {
    addToCart(product, quantity);
  };

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity >= 1) {
      setQuantity(newQuantity);
    }
  };

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  if (!product) {
    return <div>Product not found</div>;
  }

  return (
    <div className="pt-24 pb-16">
      <div className="container mx-auto px-4">
        {/* Breadcrumbs */}
        <div className="flex items-center text-sm mb-8">
          <Link to="/" className="text-gray-500 hover:text-rose-gold">Home</Link>
          <ChevronRight size={14} className="mx-2 text-gray-400" />
          <Link to="/products" className="text-gray-500 hover:text-rose-gold">Products</Link>
          {category && (
            <>
              <ChevronRight size={14} className="mx-2 text-gray-400" />
              <Link 
                to={`/products?category=${category.id}`} 
                className="text-gray-500 hover:text-rose-gold"
              >
                {category.name}
              </Link>
            </>
          )}
          <ChevronRight size={14} className="mx-2 text-gray-400" />
          <span className="text-plum">{product.name}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Product Images */}
          <div>
            <div className="relative bg-cream rounded-lg overflow-hidden">
              {product.isNew && (
                <span className="absolute top-4 left-4 bg-plum text-white text-xs uppercase tracking-wider px-2 py-1 z-10 rounded">
                  New
                </span>
              )}
              {product.discount > 0 && (
                <span className="absolute top-4 right-4 bg-rose-gold text-white text-xs uppercase tracking-wider px-2 py-1 z-10 rounded">
                  {product.discount}% off
                </span>
              )}
              <img 
                src={selectedImage} 
                alt={product.name} 
                className="w-full h-auto object-cover"
              />
            </div>
            
            {/* Thumbnail images */}
            {product.images.length > 1 && (
              <div className="grid grid-cols-5 gap-2 mt-4">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(image)}
                    className={`border rounded-md overflow-hidden ${
                      selectedImage === image ? 'border-rose-gold' : 'border-gray-200'
                    }`}
                  >
                    <img 
                      src={image} 
                      alt={`${product.name} - Image ${index + 1}`} 
                      className="w-full h-auto object-cover aspect-square"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {/* Product Info */}
          <div>
            <h1 className="text-3xl font-serif font-bold text-plum mb-2">{product.name}</h1>
            
            {/* Rating */}
            <div className="flex items-center mb-4">
              <div className="flex">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star 
                    key={i} 
                    size={18}
                    className={`${i < product.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`} 
                  />
                ))}
              </div>
              <span className="ml-2 text-gray-500">({product.reviewCount} reviews)</span>
            </div>
            
            {/* Price */}
            <div className="mb-6">
              {product.originalPrice && product.originalPrice > product.price ? (
                <div className="flex items-center">
                  <span className="text-2xl font-bold text-rose-gold">${product.price.toFixed(2)}</span>
                  <span className="text-gray-400 line-through ml-3">${product.originalPrice.toFixed(2)}</span>
                  <span className="ml-3 bg-rose-gold/10 text-rose-gold px-2 py-1 text-xs font-medium rounded">
                    Save ${(product.originalPrice - product.price).toFixed(2)}
                  </span>
                </div>
              ) : (
                <span className="text-2xl font-bold text-plum">${product.price.toFixed(2)}</span>
              )}
            </div>
            
            {/* Description */}
            <p className="text-gray-600 mb-6">{product.shortDescription}</p>
            
            {/* Benefits */}
            <div className="mb-8">
              <h3 className="font-medium text-plum mb-2">Key Benefits:</h3>
              <ul className="space-y-1">
                {product.benefits.map((benefit, index) => (
                  <li key={index} className="flex items-start">
                    <span className="mr-2 text-rose-gold">•</span>
                    <span className="text-gray-600">{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            {/* Add to Cart */}
            <div className="mb-8">
              <div className="flex items-center mb-4">
                <div className="flex items-center border border-gray-200 rounded-md">
                  <button
                    onClick={() => handleQuantityChange(quantity - 1)}
                    className="px-3 py-2 text-gray-500 hover:text-plum disabled:opacity-50"
                    disabled={quantity <= 1}
                  >
                    <Minus size={16} />
                  </button>
                  <span className="px-4 py-2 border-x border-gray-200 min-w-[40px] text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => handleQuantityChange(quantity + 1)}
                    className="px-3 py-2 text-gray-500 hover:text-plum"
                  >
                    <Plus size={16} />
                  </button>
                </div>
                
                <div className="ml-4 flex-grow flex space-x-2">
                  <button
                    onClick={handleAddToCart}
                    className="flex-grow flex items-center justify-center gap-2 bg-plum text-white py-3 rounded-md hover:bg-plum/90 transition-colors"
                  >
                    <ShoppingBag size={18} />
                    <span>Add to Cart</span>
                  </button>
                  
                  <button
                    onClick={toggleFavorite}
                    className={`w-12 flex items-center justify-center rounded-md border ${
                      isFavorite 
                        ? 'bg-rose-gold/10 border-rose-gold text-rose-gold' 
                        : 'border-gray-200 text-gray-400 hover:border-rose-gold hover:text-rose-gold'
                    }`}
                    aria-label={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    <Heart size={18} fill={isFavorite ? 'currentColor' : 'none'} />
                  </button>
                </div>
              </div>
            </div>
            
            {/* Shipping/Returns */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <div className="flex items-center">
                <Truck size={20} className="text-plum mr-3" />
                <div>
                  <p className="text-sm font-medium text-plum">Free Shipping</p>
                  <p className="text-xs text-gray-500">On orders over $50</p>
                </div>
              </div>
              <div className="flex items-center">
                <Shield size={20} className="text-plum mr-3" />
                <div>
                  <p className="text-sm font-medium text-plum">Quality Promise</p>
                  <p className="text-xs text-gray-500">100% authentic products</p>
                </div>
              </div>
              <div className="flex items-center">
                <RotateCcw size={20} className="text-plum mr-3" />
                <div>
                  <p className="text-sm font-medium text-plum">Easy Returns</p>
                  <p className="text-xs text-gray-500">30-day returns policy</p>
                </div>
              </div>
            </div>
            
            {/* Tabs */}
            <div>
              <div className="flex border-b border-gray-200">
                <button
                  onClick={() => setActiveTab('description')}
                  className={`py-3 px-4 font-medium text-sm ${
                    activeTab === 'description' 
                      ? 'border-b-2 border-rose-gold text-plum' 
                      : 'text-gray-500 hover:text-plum'
                  }`}
                >
                  Description
                </button>
                <button
                  onClick={() => setActiveTab('ingredients')}
                  className={`py-3 px-4 font-medium text-sm ${
                    activeTab === 'ingredients' 
                      ? 'border-b-2 border-rose-gold text-plum' 
                      : 'text-gray-500 hover:text-plum'
                  }`}
                >
                  Ingredients
                </button>
                <button
                  onClick={() => setActiveTab('how-to-use')}
                  className={`py-3 px-4 font-medium text-sm ${
                    activeTab === 'how-to-use' 
                      ? 'border-b-2 border-rose-gold text-plum' 
                      : 'text-gray-500 hover:text-plum'
                  }`}
                >
                  How to Use
                </button>
              </div>
              
              <div className="py-4">
                {activeTab === 'description' && (
                  <div className="text-gray-600 space-y-4">
                    <p>{product.longDescription || product.shortDescription}</p>
                  </div>
                )}
                
                {activeTab === 'ingredients' && (
                  <div className="text-gray-600">
                    <p className="mb-4">All of our products are formulated without parabens, sulfates, and phthalates.</p>
                    <p className="text-xs leading-relaxed">
                      {product.ingredients || 'Aqua/Water, Glycerin, Isododecane, Dimethicone, Cetyl PEG/PPG-10/1 Dimethicone, Nylon-12, Phenoxyethanol, Disteardimonium Hectorite, Sodium Chloride, Dipropylene Glycol, PEG-10 Dimethicone, Stearic Acid, Dimethicone/Vinyl Dimethicone Crosspolymer, Tocopheryl Acetate.'}
                    </p>
                  </div>
                )}
                
                {activeTab === 'how-to-use' && (
                  <div className="text-gray-600">
                    <ol className="space-y-2 list-decimal pl-4">
                      {product.howToUse ? product.howToUse.map((step, i) => (
                        <li key={i}>{step}</li>
                      )) : (
                        <>
                          <li>Apply product to clean, moisturized skin.</li>
                          <li>Use fingertips or a brush to blend the product evenly.</li>
                          <li>Layer as needed to build desired coverage or intensity.</li>
                          <li>For best results, set with a setting spray or powder.</li>
                        </>
                      )}
                    </ol>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;
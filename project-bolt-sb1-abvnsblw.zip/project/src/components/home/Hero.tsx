import React from 'react';
import { Link } from 'react-router-dom';

const Hero: React.FC = () => {
  return (
    <section className="relative h-screen max-h-[800px] overflow-hidden">
      {/* Hero Background Image */}
      <div className="absolute inset-0">
        <img 
          src="https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=1600" 
          alt="Makeup products on display" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-plum/70 to-transparent"></div>
      </div>

      {/* Hero Content */}
      <div className="container mx-auto px-4 relative h-full flex items-center">
        <div className="max-w-lg text-white">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold leading-tight animate-fadeIn">
            Discover Your Perfect Look
          </h1>
          <p className="mt-6 text-lg md:text-xl text-white/90 animate-fadeIn animation-delay-300">
            Luxury makeup crafted with premium ingredients for the modern beauty enthusiast.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-4 animate-fadeIn animation-delay-600">
            <Link 
              to="/products" 
              className="px-8 py-3 bg-rose-gold text-white rounded-md font-medium hover:bg-rose-gold/90 transition-colors"
            >
              Shop Now
            </Link>
            <Link 
              to="/products?category=5" 
              className="px-8 py-3 bg-transparent border border-white text-white rounded-md font-medium hover:bg-white/10 transition-colors"
            >
              New Collection
            </Link>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-8 h-12 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-scrollDown"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
import React from 'react';
import { Link } from 'react-router-dom';

const collections = [
  {
    id: 1,
    name: 'Summer Glow',
    description: 'Radiant, sun-kissed looks for the perfect summer glow.',
    image: 'https://images.pexels.com/photos/2681751/pexels-photo-2681751.jpeg?auto=compress&cs=tinysrgb&w=1600',
    link: '/products?collection=summer-glow'
  },
  {
    id: 2,
    name: 'Everyday Essentials',
    description: 'Must-have products for your daily beauty routine.',
    image: 'https://images.pexels.com/photos/2693644/pexels-photo-2693644.jpeg?auto=compress&cs=tinysrgb&w=1600',
    link: '/products?collection=essentials'
  },
  {
    id: 3,
    name: 'Evening Glamour',
    description: 'Bold, sophisticated looks for special nights out.',
    image: 'https://images.pexels.com/photos/458766/pexels-photo-458766.jpeg?auto=compress&cs=tinysrgb&w=1600',
    link: '/products?collection=evening-glamour'
  }
];

const Collections: React.FC = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold text-plum">Collections</h2>
          <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
            Explore our carefully curated collections designed for every occasion and style.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {collections.map((collection) => (
            <Link 
              key={collection.id}
              to={collection.link}
              className="group block relative overflow-hidden rounded-lg"
            >
              <div className="aspect-w-3 aspect-h-4 w-full">
                <img 
                  src={collection.image} 
                  alt={collection.name} 
                  className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent"></div>
                <div className="absolute inset-0 flex flex-col justify-end p-6">
                  <h3 className="text-2xl font-serif font-bold text-white">{collection.name}</h3>
                  <p className="text-white/80 mt-2">{collection.description}</p>
                  <span className="mt-4 inline-block text-rose-gold font-medium group-hover:underline">
                    Explore Collection
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Collections;
import React, { useState } from 'react';

const NewsletterSection: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      // Here you would typically send the email to your newsletter service
      setIsSubmitted(true);
      setEmail('');
      
      // Reset the submitted state after 5 seconds
      setTimeout(() => {
        setIsSubmitted(false);
      }, 5000);
    }
  };

  return (
    <section className="py-16 bg-plum text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-serif font-bold">Join Our Beauty Community</h2>
          <p className="mt-4 text-white/80">
            Subscribe to our newsletter for exclusive offers, beauty tips, and first access to new product launches.
          </p>
          
          <form onSubmit={handleSubmit} className="mt-8 max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email address"
                className="flex-grow px-4 py-3 rounded-md bg-white/10 border border-white/20 focus:outline-none focus:border-rose-gold text-white placeholder-white/60"
                required
              />
              <button
                type="submit"
                className="px-6 py-3 bg-rose-gold text-white font-medium rounded-md hover:bg-rose-gold/90 transition-colors"
              >
                Subscribe
              </button>
            </div>
            
            {isSubmitted && (
              <p className="mt-4 text-green-300 animate-fadeIn">
                Thank you for subscribing! We've sent a confirmation to your email.
              </p>
            )}
            
            <p className="mt-4 text-sm text-white/60">
              By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.
            </p>
          </form>
        </div>
      </div>
    </section>
  );
};

export default NewsletterSection;
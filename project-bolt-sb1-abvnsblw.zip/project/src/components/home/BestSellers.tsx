import React from 'react';
import { Link } from 'react-router-dom';
import ProductGrid from '../product/ProductGrid';
import { bestSellerProducts } from '../../data/products';

const BestSellers: React.FC = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl font-serif font-bold text-plum">Best Sellers</h2>
            <p className="mt-2 text-gray-600">
              Our most popular products loved by customers worldwide.
            </p>
          </div>
          <Link 
            to="/products?sort=popular" 
            className="hidden md:block text-rose-gold font-medium hover:underline"
          >
            View All Best Sellers
          </Link>
        </div>

        <ProductGrid products={bestSellerProducts} columns={4} />

        <div className="mt-8 text-center md:hidden">
          <Link 
            to="/products?sort=popular" 
            className="inline-block text-rose-gold font-medium hover:underline"
          >
            View All Best Sellers
          </Link>
        </div>
      </div>
    </section>
  );
};

export default BestSellers;
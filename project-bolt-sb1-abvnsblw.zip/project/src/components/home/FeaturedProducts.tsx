import React from 'react';
import { Link } from 'react-router-dom';
import ProductGrid from '../product/ProductGrid';
import { featuredProducts } from '../../data/products';

const FeaturedProducts: React.FC = () => {
  return (
    <section className="py-16 bg-cream">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-serif font-bold text-plum">Featured Products</h2>
          <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
            Discover our most-loved products, chosen for their exceptional quality and stunning results.
          </p>
        </div>

        <ProductGrid products={featuredProducts} columns={4} />

        <div className="mt-12 text-center">
          <Link 
            to="/products" 
            className="inline-block px-6 py-3 border-2 border-plum text-plum font-medium rounded-md hover:bg-plum hover:text-white transition-colors"
          >
            View All Products
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
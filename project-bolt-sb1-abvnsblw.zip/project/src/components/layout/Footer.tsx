import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-plum text-white">
      <div className="container mx-auto px-4 pt-12 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Column */}
          <div className="space-y-4">
            <h3 className="text-2xl font-serif">Lumière</h3>
            <p className="text-gray-300">
              Luxury makeup and beauty products for the modern woman. Discover your perfect look with Lumière.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-rose-gold transition" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white hover:text-rose-gold transition" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-rose-gold transition" aria-label="Twitter">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Shop Column */}
          <div>
            <h4 className="text-lg font-medium mb-4">Shop</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/products?category=1" className="text-gray-300 hover:text-rose-gold transition">
                  Face
                </Link>
              </li>
              <li>
                <Link to="/products?category=2" className="text-gray-300 hover:text-rose-gold transition">
                  Eyes
                </Link>
              </li>
              <li>
                <Link to="/products?category=3" className="text-gray-300 hover:text-rose-gold transition">
                  Lips
                </Link>
              </li>
              <li>
                <Link to="/products?category=4" className="text-gray-300 hover:text-rose-gold transition">
                  Cheeks
                </Link>
              </li>
              <li>
                <Link to="/products?category=5" className="text-gray-300 hover:text-rose-gold transition">
                  Skincare
                </Link>
              </li>
              <li>
                <Link to="/products?category=6" className="text-gray-300 hover:text-rose-gold transition">
                  Brushes & Tools
                </Link>
              </li>
            </ul>
          </div>

          {/* Company Column */}
          <div>
            <h4 className="text-lg font-medium mb-4">Company</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/about" className="text-gray-300 hover:text-rose-gold transition">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-300 hover:text-rose-gold transition">
                  Contact
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-rose-gold transition">
                  Careers
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-rose-gold transition">
                  Sustainability
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-300 hover:text-rose-gold transition">
                  Press
                </a>
              </li>
            </ul>
          </div>

          {/* Newsletter Column */}
          <div>
            <h4 className="text-lg font-medium mb-4">Stay Connected</h4>
            <p className="text-gray-300 mb-4">
              Subscribe to our newsletter for exclusive offers, beauty tips, and product launches.
            </p>
            <form className="space-y-2">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email address"
                  className="px-4 py-2 bg-white bg-opacity-10 rounded-l-md focus:outline-none focus:ring-1 focus:ring-rose-gold w-full"
                />
                <button 
                  type="submit" 
                  className="bg-rose-gold hover:bg-rose-gold/90 text-white px-4 rounded-r-md transition-colors"
                  aria-label="Subscribe"
                >
                  <Mail size={18} />
                </button>
              </div>
              <p className="text-xs text-gray-400">
                By subscribing, you agree to our Privacy Policy and consent to receive updates from our company.
              </p>
            </form>
          </div>
        </div>

        <div className="border-t border-white border-opacity-10 mt-10 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-300 text-sm">
            &copy; {currentYear} Lumière Beauty. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-300 hover:text-rose-gold text-sm transition">
              Privacy Policy
            </a>
            <a href="#" className="text-gray-300 hover:text-rose-gold text-sm transition">
              Terms of Service
            </a>
            <a href="#" className="text-gray-300 hover:text-rose-gold text-sm transition">
              Shipping Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, ShoppingBag, Menu, X, ChevronDown } from 'lucide-react';
import { useCart } from '../../context/CartContext';
import { categories } from '../../data/categories';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const { totalItems } = useCart();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Close mobile menu when route changes
    setIsMenuOpen(false);
    setShowSearch(false);
  }, [location]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
    if (showSearch) setShowSearch(false);
  };

  const toggleSearch = () => {
    setShowSearch(!showSearch);
    if (isMenuOpen) setIsMenuOpen(false);
  };

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="text-2xl font-serif font-bold text-plum">
            Lumière
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-plum hover:text-rose-gold transition">
              Home
            </Link>
            <div className="relative group">
              <button className="flex items-center text-plum hover:text-rose-gold transition">
                Shop <ChevronDown size={16} className="ml-1" />
              </button>
              <div className="absolute left-0 mt-2 w-56 bg-white shadow-lg rounded-md hidden group-hover:block">
                <div className="py-2 grid grid-cols-1 gap-1">
                  {categories.map((category) => (
                    <Link 
                      key={category.id}
                      to={`/products?category=${category.id}`}
                      className="px-4 py-2 hover:bg-cream transition"
                    >
                      {category.name}
                    </Link>
                  ))}
                  <div className="border-t border-gray-100 mt-2 pt-2">
                    <Link 
                      to="/products" 
                      className="px-4 py-2 font-medium hover:bg-cream transition block"
                    >
                      View All Products
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <Link to="/about" className="text-plum hover:text-rose-gold transition">
              About
            </Link>
            <Link to="/contact" className="text-plum hover:text-rose-gold transition">
              Contact
            </Link>
          </nav>

          {/* Icons */}
          <div className="flex items-center space-x-4">
            <button 
              onClick={toggleSearch}
              className="text-plum hover:text-rose-gold transition"
              aria-label="Search"
            >
              <Search size={20} />
            </button>
            <Link 
              to="/cart" 
              className="text-plum hover:text-rose-gold transition relative"
              aria-label="Cart"
            >
              <ShoppingBag size={20} />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-rose-gold text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                  {totalItems}
                </span>
              )}
            </Link>
            <button
              className="md:hidden text-plum hover:text-rose-gold transition"
              onClick={toggleMenu}
              aria-label="Menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Search Bar */}
        {showSearch && (
          <div className="mt-4 pb-4 animate-fadeDown">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-2 border border-gray-200 rounded-md focus:outline-none focus:border-rose-gold"
              />
              <button 
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-rose-gold"
                aria-label="Submit search"
              >
                <Search size={18} />
              </button>
            </div>
          </div>
        )}

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white absolute left-0 right-0 top-full shadow-md animate-fadeDown">
            <nav className="container mx-auto px-4 py-4 flex flex-col">
              <Link 
                to="/" 
                className="py-3 border-b border-gray-100 text-plum hover:text-rose-gold"
              >
                Home
              </Link>
              {categories.map((category) => (
                <Link 
                  key={category.id}
                  to={`/products?category=${category.id}`}
                  className="py-3 border-b border-gray-100 text-plum hover:text-rose-gold pl-4"
                >
                  {category.name}
                </Link>
              ))}
              <Link 
                to="/products" 
                className="py-3 border-b border-gray-100 text-plum hover:text-rose-gold font-medium"
              >
                All Products
              </Link>
              <Link 
                to="/about" 
                className="py-3 border-b border-gray-100 text-plum hover:text-rose-gold"
              >
                About
              </Link>
              <Link 
                to="/contact" 
                className="py-3 text-plum hover:text-rose-gold"
              >
                Contact
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;